#include <iostream>
#include <vector>
#include <unordered_map>
#include <iomanip>

using namespace std;

class Splitwise {
private:
    // Map to store balances for each user
    unordered_map<string, int> balances;

public:
    // Add a user to the system
    void addUser(const string& user) {
        if (balances.find(user) == balances.end()) {
            balances[user] = 0;
            cout << "User " << user << " added successfully." << endl;
        } else {
            cout << "User " << user << " already exists." << endl;
        }
    }

    // Record a transaction
    void addTransaction(const string& payer, const vector<pair<string, int>>& expenses) {
        if (balances.find(payer) == balances.end()) {
            cout << "Payer does not exist." << endl;
            return;
        }

        int totalAmount = 0;
        for (const auto& expense : expenses) {
            const string& payee = expense.first;
            int amount = expense.second;

            if (balances.find(payee) == balances.end()) {
                cout << "Payee " << payee << " does not exist." << endl;
                return;
            }

            // Calculate the total amount to be subtracted from payer's balance
            totalAmount += amount;

            // Update the payee's balance
            balances[payee] += amount;
        }

        // Update the payer's balance
        balances[payer] -= totalAmount;
        cout << "Transaction recorded successfully." << endl;
    }

    // Display all balances
    void displayBalances() const {
        cout << "Current balances:" << endl;
        for (const auto& [user, balance] : balances) {
            if (balance != 0) {
                cout << setw(10) << user << ": " << balance << endl;
            }
        }
    }
};

int main() {
    Splitwise splitwise;

    // Adding users
    splitwise.addUser("Alice");
    splitwise.addUser("Bob");
    splitwise.addUser("Charlie");

    // Recording transactions
    splitwise.addTransaction("Alice", {{"Bob", 30}, {"Charlie", 20}});
    splitwise.addTransaction("Bob", {{"Charlie", 10}});

    // Displaying balances
    splitwise.displayBalances();

    return 0;
}